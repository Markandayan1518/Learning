package pack;

public class Tester {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();

		calculator.add(5, 6);
		calculator.multiply(0, 5);
		calculator.multiply(5, 6);
	}
}
