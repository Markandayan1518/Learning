

public class RegularCustomer extends Customer{
       	private float discount;
       	public RegularCustomer(String customerName, long teleNo1, long teleNo2, long teleNo3,Address addr,float discount){
			super(customerName,teleNo1,teleNo2,teleNo3,addr);
			this.discount=discount;
		}
		public void displayCustomerInformation(){
			System.out.println("Customer Id	:"+ customerId);
			System.out.println("Customer Name	:"+customerName);
			System.out.println("Contact Nos	:"+ contactNos[0]+" "+ contactNos[1]+" "+contactNos[2]);
			System.out.println("Address	:");
			System.out.println("         "+address.getAddressLine());
			System.out.println("         "+address.getCity());
			System.out.println("         "+address.getState());
			System.out.println("         "+address.getZip());
			System.out.println("Discount:"+discount);
        }
        public float getDiscount(){
		 		   return discount;
	   }
}
