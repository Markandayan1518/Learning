
interface Tax{
	       float TAX = 4.0f;
	       public float computeTax();
}
public class PurchaseBill implements Tax{
	private int billId;
	private float billAmount;
	private static int counter;
	private Customer customer;
	private String typeOfCustomer;

	static{
		counter=5000;
	}

	public PurchaseBill(Customer cust,float billAmount,String typeOfCustomer){
		customer=cust;
		billId=++counter;
		this.billAmount=billAmount;
		this.typeOfCustomer=typeOfCustomer;
	}

	public Customer getCustomer(){
		return customer;
	}

	public int getBillId(){
		return billId;
	}

	public float computeTax(){
		float taxAmount=0.0f;
		taxAmount=(billAmount*TAX)/100.00f;
		return taxAmount;
	}
	public void calculateBillAmount(String modeOfPayment,int processingCharge){
		if(modeOfPayment.equalsIgnoreCase("Credit")){
			billAmount=billAmount + (billAmount*processingCharge/100.00f);
		}

		billAmount=billAmount + computeTax();

		if(typeOfCustomer.equalsIgnoreCase("Regular")){
			/* The below statement uses the concept of Typecasting of objects
			   which is not included as part of this course. Learner need not 
			   learn this concept, this has been written to complete the
			   logic of bill calculation */
			RegularCustomer regCust = (RegularCustomer)customer;
			billAmount=billAmount - (billAmount*regCust.getDiscount()/100.0f);
		}
		else{
			if(typeOfCustomer.equalsIgnoreCase("Privileged")){
				String cardType=null;
				String gift=null;
				/* The below statement uses the concept of Typecasting of objects
			  	   which is not included as part of this course. Learner need not 
			           learn this concept, this has been written to complete the
			           logic of bill calculation */
				PrivilegedCustomer prvCust = (PrivilegedCustomer)customer;
				cardType=prvCust.getMemCardType();
				if(cardType.equalsIgnoreCase("Platinum")){
					gift="Washing Machine";
				}
				else if(cardType.equalsIgnoreCase("Gold")){
					gift="Microwave Oven";
				}
				else if(cardType.equalsIgnoreCase("Silver")){
					gift="Purifier";
				}
				System.out.println("You have got a gift: "+ gift + ". Please collect it from the gift counter");

			}
		}

	}
	public void displayBill(){
			PrintDetails printObj=new PrintDetails();
			printObj.printHeader('-',80);
			printObj.printHeader(" 				Easy Shop Retail Store Bill");
			printObj.printHeader('-',80);
			System.out.println("");
			System.out.println("Bill Id		:"+ billId);
			customer.displayCustomerInformation();
			System.out.println("Final bill amount to be paid	:Rs."+billAmount);
			System.out.println("");
			printObj.printHeader('-',80);
			printObj.printHeader("				Thank You!!! Visit Again");
			printObj.printHeader('-',80);
	}

}
class PrintDetails{
	public void printHeader(char c){
		for(int counter=0;counter<70;counter++){
			System.out.print(c);
		}
	}
	public void printHeader(char c, int no){
		for(int counter=0;counter<no;counter++){
			System.out.print(c);
		}
	}
	public void printHeader(String s){
		System.out.println(s);
	}
}