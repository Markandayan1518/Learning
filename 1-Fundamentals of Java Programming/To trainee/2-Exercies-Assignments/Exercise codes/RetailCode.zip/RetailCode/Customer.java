
public abstract class Customer{
	private int customerId;
	protected String customerName;
	private long contactNos[]=new long[3];
	Address address;
	private static int counter=1000;

	public Customer(String customerName, long teleNo1, long teleNo2, long teleNo3,Address add){
		customerId=++counter;
		this.customerName=customerName;
		contactNos[0]=teleNo1;
		contactNos[1]=teleNo2;
		contactNos[2]=teleNo3;
		address=add;
	}
	public void setAddress(Address address){
	        this.address=address;
    }
    abstract public void  displayCustomerInformation();
}
