
public class Retail{
	public static void main(String args[]){
		String typeOfCustomer="Regular";
		String modeOfPayment="Cash";
		int processingCharge=150;
		Customer cust=null;
		if(typeOfCustomer.equalsIgnoreCase("Regular")){
			Address add1 = new Address();
			add1.setAddressLine("No.333,ABC street,");
			add1.setCity("Mysore,");
			add1.setState("Karnataka,");
			add1.setZip("570001");
			cust=new RegularCustomer("John",9980788712L,9886124566L,9496781256L,add1,10.0f);

		}
		else if(typeOfCustomer.equalsIgnoreCase("Privileged")){
			Address add2 = new Address();
			add2.setAddressLine("No.335,ABC street,");
			add2.setCity("Mysore,");
			add2.setState("Karnataka,");
			add2.setZip("570001");
			cust=new PrivilegedCustomer("Jennifer",2544871,989789956,949629145,add2,"Silver");
		}

		PurchaseBill purObj=new PurchaseBill(cust,2000.00f,typeOfCustomer);
		purObj.calculateBillAmount(modeOfPayment,processingCharge);
		purObj.displayBill();
	}
}


