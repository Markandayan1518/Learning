package annotationdemo;
//Uncomment the annotation below to observe changes
@SuppressWarnings("unused")
public class AnnotationDemo {

	public static void main(String[] args) {
		int empId;

	}

}
