package stringdemo;

public class StringFunctions {
	public static void main(String[] args) {
		String productName = "Acer_Laptop";
		if (productName.contains("Laptop")) {
			System.out.println("The selected product is a laptop");
		}
		/* indexOf() returns the index of the given character */
		String emailId = "apoorv@infosys.com";
		int position = emailId.indexOf("@");
		System.out.println(position); // prints 6

		int positionOfHash = emailId.indexOf("#");
		System.out.println(positionOfHash);

		String newProductName = productName.replace("Laptop", "Desktop");
		System.out.println(newProductName);

		// replace() can also be used for replacing character values

		/* valueOf() methods converts other data types into string value */
		int productId = 1094;
		double productPrice = 400.50;
		System.out.println("product ID is : " + String.valueOf(productId));
		System.out.println("Price is : " + String.valueOf(productPrice));

	}
}
