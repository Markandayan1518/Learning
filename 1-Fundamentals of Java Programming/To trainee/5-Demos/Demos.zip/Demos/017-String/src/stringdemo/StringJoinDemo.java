package stringdemo;

public class StringJoinDemo {
	public static void main(String[] args) {
		String year = "2012", month = "feb", date = "21";
		String dateOfJoining = String.join("/", date, month, year);
		System.out.println(dateOfJoining);
	}
}
