package locattimedemo;


import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class LocalTimeDemo {
	public static void main(String[] args) {
		LocalTime swipedInTime = LocalTime.of(9, 0, 0);
		// creates a LocalTime object with 9 am as time
		System.out.println("Swipe in time : "+swipedInTime);

		double workingHour = 9.15;
		// the employee has to be present in the company for 9 hours 15 mins

		LocalTime swipeOutTime = swipedInTime;
		// creates another reference
		int minutes = (int) ((workingHour % 1) * 100);
		swipeOutTime = swipeOutTime.plusMinutes(minutes);

		int hours = (int) (workingHour - (int) ((workingHour % 1)));
		swipeOutTime = swipeOutTime.plusHours(hours);
		System.out.println("You can swipe out at : " + swipeOutTime.format(DateTimeFormatter.ofPattern("hh:mm a")));
		//Here formatting is done to display it in 12 hour format
	}
}
