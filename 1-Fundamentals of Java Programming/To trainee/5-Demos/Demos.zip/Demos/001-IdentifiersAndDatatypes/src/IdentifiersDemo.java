

@SuppressWarnings("unused")
public class IdentifiersDemo {
	public static void main(String[] args) {
		String custName = "Scott";
		int custId = 1001;
		long telephoneNo = 1234567890L;
		float billAmount = 125.35f;
		boolean isRegular = false;
	}
}
