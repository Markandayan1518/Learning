package bufferandbuilderdemo;
public class BufferDemo {
	public static void main(String[] args) {
		StringBuffer sBuffer = new StringBuffer(" test");
		System.out.println(sBuffer.append("String Buffer"));
		System.out.println(sBuffer);
		String s2 = "Yellow";
		System.out.println("Concatinating Cabs to Yellow using" +
				" concat(): "+s2.concat(" Cabs"));
		System.out.println(s2);
	}
}
