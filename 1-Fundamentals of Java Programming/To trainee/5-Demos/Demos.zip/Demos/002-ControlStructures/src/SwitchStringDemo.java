

public class SwitchStringDemo {
	public static void main(String[] args) {
		String week = "Sunday";
		String output;
		switch (week) {
		case "Monday":
			output = "Sunday has gone. Get ready for office!!";
			break;
		case "Tuesday":
			output = "Saturday is so far. It's just Tuesday";
			break;
		case "Wednesday":
			output = "On Wednesday,somehow managed to cop up with work";
			break;
		case "Thursday":
			output = "Oops now again we can see Saturday is coming.";
			break;
		case "Friday":
			output = "ahhhhh !!!! Just Last WeekDay";
			break;
		case "Saturday":
			output = "Yeppiiii !!!! Finally wait is over.";
			break;
		case "Sunday":
			output = "Ohh !! Again Monday is knocking";
			break;
		default:
			output = "Invalid Week. ";
			break;
		}
		System.out.println("Your Mood according to Week Day :" +output);

	}

}
