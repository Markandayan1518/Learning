

public class StarDemo {
	public static void main(String[] args) {
		String choice = "usingForLoop"; //this is taken as input for switch case
		int noOfIterations = 5;
		int i, j;
		switch (choice) {
		case "usingForLoop": //String value is taken as a case
			if (noOfIterations > 10) {
				System.out.println("We are going to break out"
						+ " of the switch case!");
				break; //this break terminates switch case
			} else {
				for (i = 1; i <= noOfIterations; i++) {
					if (i == noOfIterations) {
						System.out.println("Breaking out of for loop!");
						break; //this break terminates the for loop
					}
					j = 1;
					while (j <= i) {
						System.out.print('*');
						j++;
					}
					System.out.println();
				}
			}
			break;
		case "usingDoWhileLoop":
			i = noOfIterations;
			do {
				for (j = i; j > 0; j--) {
					System.out.print('*');
				}
				i--;
				System.out.println();
			} while (i > 0);
			break;
		default:
			System.out.println("Sorry! Wrong choice!");
			break;
		}
	}
}
