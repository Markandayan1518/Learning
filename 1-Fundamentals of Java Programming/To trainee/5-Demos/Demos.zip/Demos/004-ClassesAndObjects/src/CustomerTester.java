

@SuppressWarnings("unused")
public class CustomerTester {
	public static void main(String[] args) {

		Customer customer = new Customer();
	}
}
