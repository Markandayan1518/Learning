

public class StaticBlockDemo {
	public static void main(String args[]) {
		Customer customer1 = new Customer("Alex");
		Customer customer2 = new Customer("Roy");
		System.out.println("Value of autoNum: " + Customer.getAutoNum());
		customer1.displayCustomer();
		customer2.displayCustomer();
	}
}

class Customer {
	private int customerId;
	private String customerName;
	private static int autoNum; // here static variable is not initialized

	static {
		System.out.println("Inside Static Block");
		int primeNumberTaken = 31;
		autoNum = (int) Math.pow(primeNumberTaken, 2);
		// when static variable initialization requires more than one line,
		// static block is used to initialize it.
		// here autoNum is initialized with a business logic with a prime
		// number.
	}

	public Customer() {
		System.out.println("Inside Default Constructor");
	}

	public Customer(String customerName) {
		this.customerId = ++autoNum;
		this.customerName = customerName;
	}

	public void displayCustomer() {
		System.out.println("Customer Id : " + customerId);
		System.out.println("Customer Name : " + customerName);
	}

	public static int getAutoNum() {
		return autoNum;
	}

}
