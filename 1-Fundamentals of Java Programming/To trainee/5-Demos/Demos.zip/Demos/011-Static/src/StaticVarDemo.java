

 class Customer1{
	private int customerId;
	private String customerName;
	private static int autoNum=1000;
	public Customer1(){
		System.out.println("Inside Default Constructor");
	}
	public Customer1( String customerName){
		this.customerId=++autoNum;
		System.out.println("Autonum is:"+autoNum);
		this.customerName=customerName;
	}
	public void displayCustomer(){
		System.out.println("Customer Id : " + customerId);
		System.out.println("Customer Name : " + customerName);
	}
	
	public static int getAutoNum() {
		return autoNum;
	}	
}
public class StaticVarDemo {
	public static void main(String args[]){
		Customer1 customer1 = new Customer1("Alex");
		Customer1 customer2 = new Customer1("Roy");		
		System.out.println(" Value of autoNum: " +Customer1.getAutoNum() );
		customer1.displayCustomer();
		customer2.displayCustomer();
	}
}
