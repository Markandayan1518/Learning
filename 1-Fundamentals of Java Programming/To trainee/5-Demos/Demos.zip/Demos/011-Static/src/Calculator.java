

public class Calculator {
	public static int add(int num1, int num2) {
		int result = num1 + num2;
		return result;
	}

	public static int mul(int num1, int num2) {
		int result = num1 * num2;
		return result;
	}
}
