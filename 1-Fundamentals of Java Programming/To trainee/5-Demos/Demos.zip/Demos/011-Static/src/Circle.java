

public class Circle{
	private double radius;
	private double area;
	private final double PI = 3.14;
	public Circle(double r){
		radius=r;
	}
	public double calculateArea(){
		area = PI * radius * radius;
		return area;
	}
	public static void main(String args[]){
		Circle circle1 = new Circle(12.5);
		System.out.println("Area ="+circle1.calculateArea());
		Circle circle2 = new Circle(15.5);
		System.out.println("Area ="+circle2.calculateArea());           
	}
}
