package localdatedemo;

import java.time.LocalDate;

public class LocalDateDemo {
	public static void main(String[] args) {
		LocalDate registeredDate = LocalDate.now();

		System.out.println("Registered on:" + registeredDate); 
		// prints today's date in yyyy-mm-dd format
		
		LocalDate validityDate = registeredDate.plusMonths(3); 
		// it adds one month to the current date 
		// and stores it in another date variable 

		System.out.println("Valid upto: " + validityDate);
	}
}
