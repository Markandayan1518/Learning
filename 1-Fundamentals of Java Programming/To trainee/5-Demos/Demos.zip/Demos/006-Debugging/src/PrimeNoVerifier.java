

public class PrimeNoVerifier {
	public static void main(String[] args) {
		int numberTaken = 29;
		boolean flag = true;
		for (int i = 2; i <= numberTaken; i++) {
			if (numberTaken % i == 0) {
				flag = false;
				break;
			}
		}
		if (flag) {
			System.out.println("Its a prime number!");
		} else {
			System.out.println("Its NOT a prime number!");
		}
	}
}
