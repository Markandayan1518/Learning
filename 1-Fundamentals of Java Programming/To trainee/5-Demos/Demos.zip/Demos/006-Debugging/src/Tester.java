

public class Tester {

	public static void main(String[] args) {

		Calculator calculator = new Calculator();

		calculator.add(5, 6);
		calculator.multiply(0, 5);
		calculator.multiply(5, 6);
	}

}

class Calculator {
	public void add(int a, int b) {
		int sum = 0;
		sum = a + b;
		System.out.println("Sum output : " + sum);
	}

	public void multiply(int a, int b) {
		int mul = 0;
		if (a != 0 && b != 0)
			mul = a * b;
		else
			System.out.println("You have entered a '0'");
		System.out.println("Multiplication output : " + mul);
	}
}