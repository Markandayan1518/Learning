
@SuppressWarnings("unused")
public class ConstructorTester {
	public static void main(String[] args) {
		System.out.println("from main method");
		System.out.println("before object creation");
		UserLogin user1=new UserLogin();
		System.out.println("after object creation");
		user1.setUserName("Scott");
		user1.setPassword("Tiger");
		
		/* creating object for User
		 * to depict the usage of parameterized constructor
		 */
		User user2 = new User("Arnold","@rn0ld");
		
		/* when using parameterized constructor
		 * as values are already passed during object creation
		 * setter methods are not needed to initialize the values
		 */
	}
}
