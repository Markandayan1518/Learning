

public class ArrayDemo {
	public static void main(String[] args) {
		int[] value = new int[3]; // array is created for 3 int values
		value[0] = 100; // first value is added
		value[1] = 200; // second value is added

		int[] primeNos = { 11, 13, 17, 19 };
		// creation and initialization done in single line

		System.out.println("prime value : " + primeNos[0]);
		// first value is retrieved by using the index value 0
		System.out.println("prime value : " + primeNos[1]);
		System.out.println("prime value : " + primeNos[2]);
		System.out.println("prime value : " + primeNos[3]);

		/* for loop can be used to access array values */
		for (int i = 0; i < 4; i++) {
			System.out.println("prime value (using for loop): " + primeNos[i]);
		}
		
		/* here rather than hard coding 4 in for loop
		 * length property can be used to determine the length of array
		 */
		
		/* improvised for loop */
		for (int i = 0; i < primeNos.length; i++) {
			System.out.println("prime value (using improvised for loop): " + primeNos[i]);
		}
	}
}
