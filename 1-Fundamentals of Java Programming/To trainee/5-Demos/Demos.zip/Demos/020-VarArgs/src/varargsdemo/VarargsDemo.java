package varargsdemo;

public class VarargsDemo {
	public static void main(String[] args) {
		Student student1 = new Student("allen", 100, 65);
		Student student2 = new Student("baskano", 87, 90, 50, 65);

		student1.displayStudentDetails();
		student2.displayStudentDetails();
	}

}

class Student {
	String name;
	int[] marks;

	public Student(String name, int... marks) {
		this.name = name;
		this.marks = marks;
	}

	public int calculateTotalMarks() {
		int total = 0;
		for (int i = 0; i < marks.length; i++) {
			total += marks[i];
		}
		return total;
	}

	public void displayStudentDetails() {
		System.out.println("Name : " + name);
		System.out.println("Total marks of " + marks.length + " subjects : "
				+ calculateTotalMarks());
	}
}
