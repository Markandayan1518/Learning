package hashcodeequalsdemo;

class Watch {
	private int modelNo;
	private String name;

	public Watch(int modelNo, String name) {
		this.modelNo = modelNo;
		this.name = name;
	}

	public int getModelNo() {
		return modelNo;
	}

	public void setModelNo(int modelNo) {
		this.modelNo = modelNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
public class EqualTester {
	public static void main(String[] args) {
		Watch titan1 = new Watch(101, "Titan style");
		Watch titan2 = new Watch(101, "Titan style");
		System.out.println(titan1.equals(titan2));
		System.out.println(titan1.hashCode());
		System.out.println(titan2.hashCode());
		System.out.println(titan1);
		System.out.println(titan2);
	}
}
