package hashcodeequalsdemo;

class WatchImprovised {
	private int modelNo;
	private String name;

	public WatchImprovised(int modelNo, String name) {
		this.modelNo = modelNo;
		this.name = name;
	}

	public boolean equals(Object obj) {
		WatchImprovised other = (WatchImprovised) obj;
		if (modelNo == other.modelNo) {
			if (name.equals(other.name)) {
				return true;
			}
		}
		return false;
	}

	public int hashCode() {
		return modelNo;
	}

	@Override
	public String toString() {
		return "WatchImprovised modelNo=" + modelNo + ", name=" + name;
	}
	
}

public class EqualTesterImprovised {
	public static void main(String[] args) {
		WatchImprovised titan1 = new WatchImprovised(101, "Titan style");
		WatchImprovised titan2 = new WatchImprovised(101, "Titan style");
		System.out.println(titan1.equals(titan2));
		System.out.println(titan1.hashCode());
		System.out.println(titan1);
		
	}
}
