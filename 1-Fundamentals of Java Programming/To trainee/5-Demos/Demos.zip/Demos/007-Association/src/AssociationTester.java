
public class AssociationTester {
	public static void main(String[] args) {
		Bill bill1=new Bill();
		bill1.setCustId(1001);
		bill1.setCustName("John");
		bill1.computeBill(2.3f, 38.5f);
		
		/* Here within AssociationTester class
		 * object and methods of Bill class is used
		 * This is "uses-a" relationship. "Association relationship"
		 */
		
		System.out.println("Customer Id\t:"+bill1.getCustId());
		System.out.println("Customer Name\t:"+bill1.getCustName());
		System.out.println("Bill Amount\t:"+bill1.getBillAmount());
	}
}
