
public class Bill {
	private int custId;
	private String custName;
	private float billAmount;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void computeBill(float qtyPurchased, float pricePerKg){
		billAmount=qtyPurchased*pricePerKg;
	}
}
