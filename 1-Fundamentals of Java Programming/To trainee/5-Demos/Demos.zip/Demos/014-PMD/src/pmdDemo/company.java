package pmdDemo;
import java.lang.*;
import java.util.Calendar;
@SuppressWarnings("unused")
public class company {
	private final int licenseId = 1001;
	private int NoOfEmployees;
	private int dateOfEstablishment;
	private boolean nocStatus;
	public boolean isNocStatus() {
		return nocStatus;
	}
	public void setNocStatus(boolean nocStatus) {
		this.nocStatus = nocStatus;
	}
	public int getLicenseId() {
		return licenseId;
	}
	public int getDateOfEstablishment() {
		return dateOfEstablishment;
	}
	public void setDateOfEstablishment(int dateOfEstablishment) {
		this.dateOfEstablishment = dateOfEstablishment;
	}
	public int getNoOfEmployees() {
		return NoOfEmployees;
	}
	public void setNoOfEmployees(int noOfEmployees) {
		NoOfEmployees = noOfEmployees;
	}
	public void DisplayDetails(){
		System.out.println("The license id is : " + this.licenseId);
		System.out.println("This establishment date is : "
				+ this.dateOfEstablishment);
		System.out.println("The number of employees are : "
				+ this.NoOfEmployees);
	}
}
