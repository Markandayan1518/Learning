

class Person1 {
	protected String uniqueId = "SSN12121";
}

class Customer1 extends Person1 {
	private String uniqueId = "C1001";

	public void displayCustomer() {
		System.out.println("Customer Unique Id: " + uniqueId);
		System.out
				.println("Customer Social Security Number: " + super.uniqueId);
	}
}

public class SuperInstanceDemo {
	public static void main(String args[]) {
		Customer1 customer = new Customer1();
		customer.displayCustomer();
	}
}
