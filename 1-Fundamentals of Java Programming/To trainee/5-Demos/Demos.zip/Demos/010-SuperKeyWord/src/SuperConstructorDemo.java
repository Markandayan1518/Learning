

@SuppressWarnings("unused")
class Employee {

	private int employeeId;

	public Employee(int eid) {
		this.employeeId = eid;
		System.out.println("Inside super class parameterised constructor");
	}

	public Employee() {
		System.out.println("Inside super class default constructor");
	}
}

@SuppressWarnings("unused")
class Educator extends Employee {
	private int sessionHandled;

	public Educator(int eid, int session) {
		// super();
		super(eid);
		this.sessionHandled = session;
		System.out.println("inside sub class constructor");
	}
}

@SuppressWarnings("unused")
public class SuperConstructorDemo {
	public static void main(String args[]) {
		Educator educator = new Educator(121212, 32);

	}
}
