package com.infy.dao;

import com.infy.bean.User;

public interface UserDAO {
	
	public String addUser(User user);
}
