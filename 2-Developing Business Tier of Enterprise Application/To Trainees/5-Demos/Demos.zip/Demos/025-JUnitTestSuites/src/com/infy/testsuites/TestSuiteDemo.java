package com.infy.testsuites;

	import org.junit.runner.RunWith;
	import org.junit.runners.Suite;
	
	@RunWith(Suite.class)
	
	@Suite.SuiteClasses({EmployeeTest.class, 
						 MathUtilityTest.class})
	public class TestSuiteDemo {
	
	}

	
	