package com.infy.exceptions;

public class UserInterface {
	public static void main(String[] args) {
		int a = 0;
		int b = 10/a;
		System.out.println(a);
		System.out.println(b);
	}
}
