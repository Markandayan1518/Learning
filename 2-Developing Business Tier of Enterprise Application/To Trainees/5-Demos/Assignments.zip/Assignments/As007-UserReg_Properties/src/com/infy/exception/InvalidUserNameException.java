package com.infy.exception;

@SuppressWarnings("serial")
public class InvalidUserNameException extends Exception{

	public InvalidUserNameException(String message)
	{
		super(message);
	}

}
