package com.infy.business.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.infy.bean.User;
import com.infy.business.validator.Validator;
import com.infy.dao.UserDAO;
import com.infy.exception.InvalidDateOfBirthException;
import com.infy.exception.InvalidPhoneNumberException;
import com.infy.exception.InvalidUserNameException;
import com.infy.exception.NoUsersFoundException;
import com.infy.resources.Factory;


/**
 * Service class to execute business logic
 * @author ETA
 */

public class UserServiceImpl implements UserService {
	/**
	 * Adds user to the database
	 * @param user, the user to be added
	 * @return The user name of the newly added user
	 * @throws InvalidUserNameException, InvalidPhoneNumberException, InvalidDateOfBirthException 
	 */
	public String addUser(User user) throws InvalidUserNameException, InvalidPhoneNumberException, InvalidDateOfBirthException {
		
		Validator validator = new Validator();
		UserDAO dao = Factory.createUserDAO();
		try
		{
			//Check the business rules
			validator.validate(user);
			
			//If data is valid, generates a suitable password
			user.setPassword("infy@123");
		}
		catch(Exception e)
		{
			if(e.getMessage().contains("Service"))
			{
				DOMConfigurator.configure("src/com/infy/resources/log4j.xml");
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		//Add the user
		return dao.addUser(user);
	}
	
	/**
	 * Gets user details from the database based on birth year
	 * @param year, the birth year to be matched
	 * @return The filtered list of users
	 * @throws NoUsersFoundException
	 */
	public List<User> getUsersByBirthYear(Integer year) throws NoUsersFoundException
	{
		// Get the user details from DAO
		UserDAO dao = Factory.createUserDAO();
		List<User> allUsers = dao.getAllUsers();
		List<User> usersByYear = new ArrayList<User>();
		
		try
		{
			// Filter the list
			for(User user : allUsers)
			{
				if(user.getDateOfBirth().get(Calendar.YEAR) == year)
					usersByYear.add(user);
			}
			
			// If the filtered list has no users, throw the appropriate user defined exception with the corresponding message
			if(usersByYear.isEmpty())
				throw new NoUsersFoundException("Service.NO_USERS_FOUND");
		}
		catch(Exception e)
		{
			if(e.getMessage().contains("Service"))
			{
				DOMConfigurator.configure("src/com/infy/resources/log4j.xml");
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		
		// Return the final list
		return usersByYear;
	}
}
