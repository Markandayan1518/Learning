package com.infy.exception;

@SuppressWarnings("serial")
public class NoUsersFoundException extends Exception {
	
	public NoUsersFoundException(String message)
	{
		super(message);
	}

}
