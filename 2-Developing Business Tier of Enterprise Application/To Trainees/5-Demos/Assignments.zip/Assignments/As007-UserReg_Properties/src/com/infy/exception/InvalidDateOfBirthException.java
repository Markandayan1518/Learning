package com.infy.exception;

@SuppressWarnings("serial")
public class InvalidDateOfBirthException extends Exception {

	public InvalidDateOfBirthException(String message)
	{
		super(message);
	}

}
