package com.infy.business.service;

import java.util.List;

import com.infy.bean.User;


/**
 * Service class to execute business logic
 * @author ETA
 */

public class UserServiceImpl implements UserService {
	/**
	 * Adds user to the database
	 * @param user, the user to be added
	 * @return The user name of the newly added user
	 * @throws Exception 
	 */
	public String addUser(User user) throws Exception {
		
		// Check the business rules
		// If data is valid, generate a suitable password
		// Add the user
		
		return null;
	}
	
	/**
	 * Gets user details from the database based on birth year
	 * @param year, the birth year to be matched
	 * @return The filtered list of users
	 * @throws Exception
	 */
	public List<User> getUsersByBirthYear(Integer year) throws Exception
	{
		// Get the user details from DAO
		// Filter the list
		// If the filtered list has no users, throw an exception with the appropriate message
		// Return the final list
		
		return null;
	}
}
