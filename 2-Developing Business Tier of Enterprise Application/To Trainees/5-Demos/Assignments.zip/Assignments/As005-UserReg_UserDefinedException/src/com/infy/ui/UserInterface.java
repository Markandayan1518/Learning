package com.infy.ui;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.infy.bean.User;
import com.infy.business.service.UserService;
import com.infy.resources.Factory;

/**
 * Creates the user object and calls the methods in the Service class.
 * This is a temporary class and will be replaced once the 
 * client tier is developed
 * @author ETA
 */

public class UserInterface {
	
public static void main(String[] args) {
		
		addUser();
		//getUsersByBirthYear();
	}
	
	public static void addUser()
	{
		User user = new User();
		user.setUserName("inFo@xyz.com");
		user.setPhoneNumber("99999P9999");
		
		Calendar dateOfBirth = Calendar.getInstance();
	    dateOfBirth.set(1999, 4, 27);
	    user.setDateOfBirth(dateOfBirth);
		
		UserService userService = Factory.createUserService();
		
		// After creating the exception classes, uncomment the code below
		
		/*try
	    {
			System.out.println("User successfully added with username: " + userService.addUser(user));
	    }
	    catch(InvalidUserNameException | InvalidPhoneNumberException | InvalidDateOfBirthException e)
	    {
	    	if(e instanceof InvalidUserNameException)
	    		System.out.println("Invalid username, it should not have info, webmaster or web-master.");
	    	if(e instanceof InvalidPhoneNumberException)
	    		System.out.println("Invalid phone number, it should have 10 digits and all the digits should not be same.");
	    	if(e instanceof InvalidDateOfBirthException)
	    		System.out.println("Invalid date of birth, your age should be at least 18 years.");
	    }*/
	}
	
	public static void getUsersByBirthYear()
	{
		Integer year = 1985;
		UserService userService = Factory.createUserService();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		
		// After creating the exception classes, uncomment the code below
		
		/*try
		{
			List<User> userList = userService.getUsersByBirthYear(year);
			
			System.out.println("Username\t\tPhone Number\t\tDate of Birth");
			System.out.println("========\t\t============\t\t=============");
			for(User user : userList)
			{
				System.out.println(user.getUserName()+"\t\t"+user.getPhoneNumber()+"\t\t"+sdf.format(user.getDateOfBirth().getTime()));
			}
		}
		catch(NoUsersFoundException e)
		{
	    	System.out.println("There are no users having the specified birth year");
		}*/
	}
}
