package com.infy.business.service;

import java.util.List;

import com.infy.bean.User;


/**
 * Service class to execute business logic
 * @author ETA
 */

public class UserServiceImpl implements UserService {
	/**
	 * Adds user to the database
	 * @param user, the user to be added
	 * @return The user name of the newly added user
	 * @throws InvalidUserNameException, InvalidPhoneNumberException, InvalidDateOfBirthException 
	 */
	// After creating the exception classes, add appropriate throws declaration in the method below
	public String addUser(User user) {
		
		// Check the business rules
		// If data is valid, generate a suitable password
		// Add the user
		
		return null;
	}
	
	/**
	 * Gets user details from the database based on birth year
	 * @param year, the birth year to be matched
	 * @return The filtered list of users
	 * @throws NoUsersFoundException
	 */
	// After creating the exception classes, add appropriate throws declaration in the method below
	public List<User> getUsersByBirthYear(Integer year)
	{
		// Get the user details from DAO
		// Filter the list
		// If the filtered list has no users, throw the appropriate user defined exception 
		// Return the final list
		
		return null;
	}
}
