package com.infy.business.service;

import java.util.List;

import com.infy.bean.User;
import com.infy.exception.InvalidDateOfBirthException;
import com.infy.exception.InvalidPhoneNumberException;
import com.infy.exception.InvalidUserNameException;
import com.infy.exception.NoUsersFoundException;

public interface UserService {
	
	public String addUser(User user) throws InvalidUserNameException, InvalidPhoneNumberException, InvalidDateOfBirthException;
	public List<User> getUsersByBirthYear(Integer year) throws NoUsersFoundException;
}
