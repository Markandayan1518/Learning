package com.infy.exception;

@SuppressWarnings("serial")
public class InvalidDateOfBirthException extends Exception {
	
	// In order to use messages with user defined exceptions,
	// create a parameterized constructor
}
