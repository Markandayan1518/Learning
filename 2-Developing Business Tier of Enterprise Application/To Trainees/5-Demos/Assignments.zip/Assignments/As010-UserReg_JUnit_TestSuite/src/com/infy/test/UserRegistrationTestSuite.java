package com.infy.test;

/**
 * Test Suite for User Registration
 * @author ETA
 */

//write the code to create a Test Suite for all the test classes

public class UserRegistrationTestSuite {
	
}
