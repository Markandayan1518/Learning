package com.infy.test;


/**
 * Test for getUsersByBirthYear of UserService
 * @author ETA
 */

public class GetUsersByBirthYearTest {
	
	 public void getUsersByBirthYearValidUser() throws Exception {
		 
		// Write the code to test valid input
	 }
	 
	 
	
	 public void getUsersByBirthYearInvalidUser() throws Exception {
		 
		// Write the code to test invalid input
	 }
}
