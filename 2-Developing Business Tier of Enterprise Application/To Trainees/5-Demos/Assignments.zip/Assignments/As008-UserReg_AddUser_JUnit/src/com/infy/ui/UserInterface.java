package com.infy.ui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.infy.bean.User;
import com.infy.business.service.UserService;
import com.infy.exception.InvalidDateOfBirthException;
import com.infy.exception.InvalidPhoneNumberException;
import com.infy.exception.InvalidUserNameException;
import com.infy.exception.NoUsersFoundException;
import com.infy.resources.AppConfig;
import com.infy.resources.Factory;

/**
 * Creates the user object and calls the methods in the Service class. This is a
 * temporary class and will be replaced once the client tier is developed
 * 
 * @author ETA
 */

public class UserInterface {

	private static UserService userService = Factory.createUserService();

	public static void main(String[] args) {

		//addUser();
		 getUsersByBirthYear();
	}

	public static void addUser() {
		User user = new User();
		user.setUserName("inFo@xyz.com");
		user.setPhoneNumber("1234567890");

		Calendar dateOfBirth = Calendar.getInstance();
		dateOfBirth.set(1985, 4, 27);
		user.setDateOfBirth(dateOfBirth);

		try
		{
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.SUCCESS") + userService.addUser(user));
		} 
		catch (InvalidUserNameException | InvalidPhoneNumberException | InvalidDateOfBirthException e)
		{
			if (e instanceof InvalidUserNameException)
				System.out.println(AppConfig.PROPERTIES.getProperty("Validator.INVALID_USERNAME"));
			if (e instanceof InvalidPhoneNumberException)
				System.out.println(AppConfig.PROPERTIES.getProperty("Validator.INVALID_PHONE_NUMBER"));
			if (e instanceof InvalidDateOfBirthException)
				System.out.println(AppConfig.PROPERTIES.getProperty("Validator.INVALID_DOB"));
		}
	}

	public static void getUsersByBirthYear() {
		Integer year = 1999;
		try 
		{
			List<User> userList = userService.getUsersByBirthYear(year);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");

			System.out.println("Username\t\tPhone Number\t\tDate of Birth");
			System.out.println("========\t\t============\t\t=============");
			for (User user : userList) {
				System.out.println(user.getUserName() + "\t\t"
						+ user.getPhoneNumber() + "\t\t"
						+ sdf.format(user.getDateOfBirth().getTime()));
			}
		}
		catch (NoUsersFoundException e) 
		{
			System.out.println(AppConfig.PROPERTIES.getProperty("Service.NO_USERS_FOUND","Error in reading messages: contact Administrator"));
		}
	}
}
