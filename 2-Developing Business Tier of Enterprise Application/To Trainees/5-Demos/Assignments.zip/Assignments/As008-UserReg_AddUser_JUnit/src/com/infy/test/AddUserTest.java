package com.infy.test;


/**
 * Test for addUser of UserService
 * @author ETA
 */

public class AddUserTest {
	
	 public void addUserValidUser() throws Exception {
		 
		// Write the code to test valid user
	 }

	
	public void addUserInvalidUserName() throws Exception {
		
		// Write the code to test invalid user
	}

	
	public void addUserInvalidPhoneNumber() throws Exception {
		
		// Write the code to test invalid user
	}

	
	public void addUserInvalidDateOfBirth() throws Exception {
		
		// Write the code to test invalid user
	}
}
