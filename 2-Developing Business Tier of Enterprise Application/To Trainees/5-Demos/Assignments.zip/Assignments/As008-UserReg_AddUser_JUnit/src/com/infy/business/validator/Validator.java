package com.infy.business.validator;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.infy.bean.User;
import com.infy.exception.InvalidDateOfBirthException;
import com.infy.exception.InvalidPhoneNumberException;
import com.infy.exception.InvalidUserNameException;

/**
 * Validates user
 * @author ETA
 */

public class Validator {
	/**
	 * Validates the user
	 * @param user
	 * @return None
	 * @throws InvalidUserNameException, InvalidPhoneNumberException, InvalidDateOfBirthException
	 */
	public void validate(User user) throws InvalidUserNameException, InvalidPhoneNumberException, InvalidDateOfBirthException {
		
		// Use isValidUserName, isValidPhoneNumber, isValidDateOfBirth to validate the user details
		// For invalid inputs throw the appropriate user defined exceptions with the corresponding messages
		try
		{
			if(!isValidUserName(user.getUserName()))
				throw new InvalidUserNameException("Validator.INVALID_USERNAME");
			if(!isValidPhoneNumber(user.getPhoneNumber()))
				throw new InvalidPhoneNumberException("Validator.INVALID_PHONE_NUMBER");
			if(!isValidDateOfBirth(user.getDateOfBirth()))
				throw new InvalidDateOfBirthException("Validator.INVALID_DOB");
		}
		catch(Exception e)
		{
			DOMConfigurator.configure("src/com/infy/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Validates the user name
	 * @param userName, the user name to be validated
	 * @return false if user name is a reserved 
	 * name (info, webmaster, web-master) or else true
	 */
	public boolean isValidUserName(String userName) {
		boolean isValid = true;
		int indexOfAt = userName.indexOf('@');
		String name = userName.substring(0, indexOfAt);
		if (name.equalsIgnoreCase("info") || name.equalsIgnoreCase("webmaster") || name.equalsIgnoreCase("web-master")) {
			isValid = false;
		}
		return isValid;
	}
	
	/**
	 * Validates the phone number
	 * @param phoneNumber, the phone number to be validated
	 * @return false if all the digits are 
	 * same (typically service provider's number) or else true
	 */
	public boolean isValidPhoneNumber(String phoneNumber) {
		boolean isValid = true;
		
		String pattern1 = phoneNumber.charAt(0) + "{10}";		// 10 repeating characters
		String pattern2 = "[\\d]{10}";							// 10 digits
		if(phoneNumber.matches(pattern1) || !phoneNumber.matches(pattern2))
			isValid = false;
		
		return isValid;
	}
	
	/**
	 * Validates the dateOfBirth
	 * @param dateOfBirth, the date of birth to be validated
	 * @return true if age >= 18 or else false
	 */
	public boolean isValidDateOfBirth(Calendar dateOfBirth) {
		boolean isValid = true;
		Calendar today = Calendar.getInstance();
		long todayTimeInMillis = today.getTimeInMillis();
		long dobTimeInMillis = dateOfBirth.getTimeInMillis();
		double differenceInYears = (todayTimeInMillis - dobTimeInMillis)/(1000.0 * 60 * 60 * 24 * 365);
		int age = (int)Math.ceil(differenceInYears);
		if(age < 18) {
			isValid = false;
		}
		return isValid;
	}
}
