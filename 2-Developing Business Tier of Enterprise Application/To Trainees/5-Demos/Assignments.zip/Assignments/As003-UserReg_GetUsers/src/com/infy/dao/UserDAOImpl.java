package com.infy.dao;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import com.infy.bean.User;

/**
 * DAO class to perform database operations
 * @author ETA
 */

public class UserDAOImpl implements UserDAO {
	
	/**
	 * Adds user to the database
	 * @param user, the user to be added
	 * @return The user name of the newly added user
	 */
	
	public String addUser(User user) {
		
		// Add user to the database
		return user.getUserName();
	}
	
	public List<User> getAllUsers()
	{
		List<User> userList = new ArrayList<User>();
		
		User user1 = new User();
		user1.setUserName("Jason@infy.com");
		user1.setPassword("infy@123");
		user1.setPhoneNumber("9845371632");
		user1.setDateOfBirth(new GregorianCalendar(1983, 1, 22));
		userList.add(user1);
		
		User user2 = new User();
		user2.setUserName("Jerry@infy.com");
		user2.setPassword("infy@123");
		user2.setPhoneNumber("9462748164");
		user2.setDateOfBirth(new GregorianCalendar(1985, 4, 14));
		userList.add(user2);
		
		User user3 = new User();
		user3.setUserName("Jack@infy.com");
		user3.setPassword("infy@123");
		user3.setPhoneNumber("9583616503");
		user3.setDateOfBirth(new GregorianCalendar(1985, 10, 18));
		userList.add(user3);
		
		User user4 = new User();
		user4.setUserName("John@infy.com");
		user4.setPassword("infy@123");
		user4.setPhoneNumber("98724367124");
		user4.setDateOfBirth(new GregorianCalendar(1981, 7, 6));
		userList.add(user4);
		
		User user5 = new User();
		user5.setUserName("Jimmy@infy.com");
		user5.setPassword("infy@123");
		user5.setPhoneNumber("9372650251");
		user5.setDateOfBirth(new GregorianCalendar(1988, 3, 21));
		userList.add(user5);
		
		return userList;
	}
}
