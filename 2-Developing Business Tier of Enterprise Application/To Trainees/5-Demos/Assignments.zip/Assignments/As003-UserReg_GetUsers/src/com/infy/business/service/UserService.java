package com.infy.business.service;

import java.util.List;

import com.infy.bean.User;

public interface UserService {
	
	public String addUser(User user);
	public List<User> getUsersByBirthYear(Integer year);
}
