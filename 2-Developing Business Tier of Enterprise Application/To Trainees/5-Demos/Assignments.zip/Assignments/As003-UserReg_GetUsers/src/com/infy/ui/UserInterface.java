package com.infy.ui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.infy.bean.User;
import com.infy.business.service.UserService;
import com.infy.resources.Factory;

/**
 * Creates the user object and calls the methods in the Service class.
 * This is a temporary class and will be replaced once the 
 * client tier is developed
 * @author ETA
 */

public class UserInterface {
	
public static void main(String[] args) {
		
		//addUser();
		getUsersByBirthYear();
	}
	
	public static void addUser()
	{
		User user = new User();
		user.setUserName("eta@xyz.com");
		user.setPhoneNumber("1234567890");
		
		Calendar dateOfBirth = Calendar.getInstance();
	    dateOfBirth.set(1985, 4, 27);
	    user.setDateOfBirth(dateOfBirth);
		
		UserService userService = Factory.createUserService();
		String uName = userService.addUser(user);
		if(uName == null)
			System.out.println("Invalid Input");
		else
			System.out.println("User successfully added with username: " + userService.addUser(user));
	}
	
	public static void getUsersByBirthYear()
	{
		Integer year = 1985;
		UserService userService = Factory.createUserService();
		List<User> userList = userService.getUsersByBirthYear(year);
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		
		if(userList.isEmpty())
		{
			System.out.println("There are no users having the specified birth year");
		}
		else
		{
			System.out.println("Username\t\tPhone Number\t\tDate of Birth");
			System.out.println("========\t\t============\t\t=============");
			for(User user : userList)
			{
				System.out.println(user.getUserName()+"\t\t"+user.getPhoneNumber()+"\t\t"+sdf.format(user.getDateOfBirth().getTime()));
			}
		}
	}
}
