package com.infy.business.service;

import com.infy.bean.User;

public interface UserService {
	
	public String addUser(User user);
}
