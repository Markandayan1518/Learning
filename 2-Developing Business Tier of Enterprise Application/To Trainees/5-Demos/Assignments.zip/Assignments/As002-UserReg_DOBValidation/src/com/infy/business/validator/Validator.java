package com.infy.business.validator;

import java.util.Calendar;

import com.infy.bean.User;

/**
 * Validates user
 * @author ETA
 */

public class Validator {
	/**
	 * Validates the user
	 * @param user
	 * @return None
	 */
	public boolean validate(User user) {

		/* Since Exception Handling course has not yet been covered, the return type of this method
		has been changed from void to boolean for demonstrative purpose. */
		
		boolean isValid = true;		
		// Use isValidUserName, isValidPhoneNumber, isValidDateOfBirth to validate the user details		
		return isValid;
	}

	/**
	 * Validates the user name
	 * @param userName the user name to be validated
	 * @return false if user name is a reserved 
	 * name (info, webmaster, web-master) or else true
	 */
	public boolean isValidUserName(String userName) {
		boolean isValid = true;
		int indexOfAt = userName.indexOf('@');
		String name = userName.substring(0, indexOfAt);
		if (name.equalsIgnoreCase("info") || name.equalsIgnoreCase("webmaster") || name.equalsIgnoreCase("web-master")) {
			isValid = false;
		}
		return isValid;
	}
	
	/**
	 * Validates the phone number
	 * @param phoneNumber, the phone number to be validated
	 * @return false if not 10 digits long or all the digits are 
	 * same (typically service provider's number), else true
	 */
	public boolean isValidPhoneNumber(String phoneNumber) {
		boolean isValid = true;
		
		String pattern1 = phoneNumber.charAt(0) + "{10}";		// 10 repeating characters
		String pattern2 = "[\\d]{10}";							// 10 digits
		if(phoneNumber.matches(pattern1) || !phoneNumber.matches(pattern2))
			isValid = false;
		
		return isValid;
	}
	
	/**
	 * Validates the dateOfBirth
	 * @param dateOfBirth, the date of birth to be validated
	 * @return true if age >= 18 or else false
	 */
	public boolean isValidDateOfBirth(Calendar dateOfBirth) {
		boolean isValid = true;
		// Write the code to validate the date of birth
		return isValid;
	}
}
